$(window).scroll(function() {    
    var scroll = $(window).scrollTop();

    /* for header */
    if (scroll >= 100) {
        $("header").addClass("active");
    } else {
        $("header").removeClass("active");
    }

    /* for brands */
    if (scroll >= 400) {
        $(".evolve-brand-wrap").addClass("active");
    }
});

$(document).ready(function(){
    $('header .main-nav-control').on('click', function(){
        $('header nav.main-nav > ul').toggleClass('open');
    });
});

function changeBar(x) {
    x.classList.toggle("change");
}